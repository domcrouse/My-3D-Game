﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class OrbHolder : MonoBehaviour
{
    //Dimitrios Martin (MAR16003880)

    [SerializeField]
    Transform playerCam;
    [SerializeField]
    float usableDistance = 2.0f;
    [SerializeField]
    GameObject inventoryOrb;
    [SerializeField]
    Material activeMaterial;
    [SerializeField]
    int totalOrbs = 4;
    [SerializeField]
    UnityEvent onComplete;
    static int orbs = 0;

    private void Start()
    {
        orbs = 0;
    }

    //when F is pressed then the user will be able to place the orb into the pre-allocated orb holder represented by a tranparent version of the orb
    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.F))
        {
            RaycastHit hit;
            if(Physics.Raycast(playerCam.position, playerCam.forward, out hit, usableDistance))
            {
                if(hit.collider.gameObject == gameObject)
                {
                    if (inventoryOrb.activeSelf)
                    {
                        inventoryOrb.SetActive(false);

                        GetComponent<Renderer>().material = activeMaterial;
                        orbs++;
                        if(orbs >= totalOrbs)
                        {
                            onComplete.Invoke();
                        }
                    }
                }
            }
        }
    }
}
