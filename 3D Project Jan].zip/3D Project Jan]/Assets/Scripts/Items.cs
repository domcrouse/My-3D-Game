﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu]
public class Item : ScriptableObject
{
    //Dimitrios Martin (MAR16003880)

    //list of test item I can pick up
    public enum ItemType
    {
        WaterOrb,
        EarthOrb,
        WindOrb,
        FireOrb
    }

    public ItemType typeOfItem;
    public int amount;

    public GameObject GetModel()
    {
        GameObject g = new GameObject();
        //takes in the type of item it would be using
        switch (typeOfItem)
        {
            default:
            case ItemType.WaterOrb: return g;
            case ItemType.FireOrb:  return g;
            case ItemType.WindOrb:  return g;
            case ItemType.EarthOrb: return g;
        }
    }
}
