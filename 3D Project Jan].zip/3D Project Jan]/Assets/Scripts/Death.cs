﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class Death : MonoBehaviour
{
    [SerializeField]
    UnityEvent dead;

    // Update is called once per frame
    void Update()
    {
        if (HealthDisplay.health <= 0)
        {
            Destroy(gameObject);
            dead.Invoke();
        }
    }
}
