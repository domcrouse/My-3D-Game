﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HookDetector : MonoBehaviour
{
    //Dimitrios Martin (MAR16003880)

    public Rigidbody hookRB;
    public Rigidbody player;
    public float dragSpeed = 5.0f;
    public float maxDistance = 10.0f;

    public GrapplingHook holder;

    public LineRenderer lr;


    void OnCollisionEnter(Collision other)
    {
        if(other.gameObject.tag != "Player")
        {
            hookRB.constraints = RigidbodyConstraints.FreezeAll;
            transform.parent = other.transform;
        }
    }

    void FixedUpdate()
    {

        if(transform.parent != holder.transform && transform.parent != null)
        {
            lr.SetPositions(new Vector3[]{
                player.transform.position,
                transform.position
            });
            if(hookRB.constraints == RigidbodyConstraints.FreezeAll){
                if(Input.GetMouseButton(1))
                {
                    player.velocity = Vector3.Normalize(transform.position - player.transform.position) * dragSpeed;
                }
                
            }    
        }  

        if(Vector3.Distance(player.transform.position, transform.position) > maxDistance){
            holder.ReturnHook();
        }
    }
}
