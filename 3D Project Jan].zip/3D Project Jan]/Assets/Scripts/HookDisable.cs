﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HookDisable : MonoBehaviour
{
    [SerializeField]
    GameObject hook;

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.E))
        {
            hook.SetActive(!hook.activeSelf);
        }
    }
}
