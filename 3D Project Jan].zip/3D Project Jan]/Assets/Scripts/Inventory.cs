﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Inventory
{
    //Dimitrios Martin (MAR16003880)

    private List<Item> itemList;


    //initialises the list
    void Start()
    {
        itemList = new List<Item>();
        AddItem(new Item { typeOfItem = Item.ItemType.EarthOrb, amount = 1 });
        Debug.Log(itemList.Count);
    }

    public void AddItem(Item item)
    {
        itemList.Add(item);
    }

}
