﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CursorLock : MonoBehaviour
{
    //Dimitrios Martin (MAR16003880)
    //locks the cursor to the screen
    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
    }
}
