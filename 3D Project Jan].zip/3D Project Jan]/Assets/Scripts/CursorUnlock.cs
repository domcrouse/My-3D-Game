﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CursorUnlock : MonoBehaviour
{
    //Dimitrios Martin (MAR16003880)

    //sets the cursor lock to false so the user can see the mouse
    void Update()
    {
        Cursor.lockState = CursorLockMode.None;

    }
}
