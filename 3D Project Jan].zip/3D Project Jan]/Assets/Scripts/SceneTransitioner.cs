﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;



public class SceneTransitioner : MonoBehaviour
{
    //Dimitrios Martin (MAR16003880)

    //takes the string value from the inspector and loads the relevant scene
    public void LoadScene(string sceneName){
        SceneManager.LoadScene(sceneName);
    }

    //closes the game
    public void Quit(){
        Application.Quit();
    }
}
