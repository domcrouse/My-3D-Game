﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerLook : MonoBehaviour
{
    //Dimitrios Martin (MAR16003880)

    [SerializeField] float sensitivity = 5.0f;


    void Update()
    {
        //retrieves the x axis of the mouse for looking left to right for the player
        transform.Rotate(0, Input.GetAxis("Mouse X") * sensitivity, 0);
    }
}
