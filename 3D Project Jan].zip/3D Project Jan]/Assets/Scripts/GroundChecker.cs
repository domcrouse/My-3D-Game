﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GroundChecker : MonoBehaviour
{

    //Dimitrios Martin (MAR16003880)
    public List <GameObject> touching = new List<GameObject>();

    void OnTriggerEnter(Collider other)
    {
        if(other.tag != "Player")
        {
            if(!touching.Contains(other.gameObject))
            {
                touching.Add(other.gameObject);
            }
        }
    }

    void OnTriggerExit(Collider other)
    {
        if(other.tag != "Player")
        {
            if(touching.Contains(other.gameObject))
            {
                touching.Remove(other.gameObject);
            }
        }
    }

}
