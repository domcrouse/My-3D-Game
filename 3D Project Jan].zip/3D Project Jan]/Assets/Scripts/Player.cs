﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    //Dimitrios Martin (MAR16003880)

    public float MoveSpeed;
    Rigidbody rb;
    public float jumpForce = 7.0f;
    public GroundChecker grounded;
    private Inventory inventory;

    //checks if the player is touching the ground
    public bool isGrounded{
        get{
            return grounded.touching.Count > 0;
        }
    }

    void Awake()
    {
        rb = GetComponent<Rigidbody>();
        inventory = new Inventory();
    }


    public void Update()
    {
        //retrieves the input from the mouse on the X axis allowing the player to look around on that axis
        //enables the player to use the WASD keys to move the player around
        float yVel = rb.velocity.y;
        rb.velocity = (transform.right * Input.GetAxis("Horizontal") * MoveSpeed) + ( transform.forward * Input.GetAxis("Vertical") * MoveSpeed) + transform.up * yVel;

        if (isGrounded && Input.GetKeyDown(KeyCode.Space))
        {
            rb.AddForce(Vector3.up * jumpForce, ForceMode.Impulse);
        }

        if (Input.GetKey(KeyCode.Escape))
        {
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
        }        
    }
    
}
