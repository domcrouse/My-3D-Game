﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraLook : MonoBehaviour
{
    //Dimitrios Martin (MAR16003880)

    [SerializeField] float Ysensitivity;
    public float Ymin = -30f;
    public float Ymax = 30f;
    float Yrotation = 0f;

    void Update()
    {
        //retrieves the y angles from the mouse in order to move the camera up and down
        Yrotation += Input.GetAxis("Mouse Y") * Ysensitivity;
        //locks the rotation according to the set minimum and maximum values
        Yrotation = Mathf.Clamp(Yrotation, Ymin, Ymax);
        //this will update the cameras position according the mouse movement
        transform.localEulerAngles = new Vector3(-Yrotation, transform.localEulerAngles.y, 0);
    }
}
