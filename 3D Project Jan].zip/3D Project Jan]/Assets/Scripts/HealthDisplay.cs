﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HealthDisplay : MonoBehaviour
{
    //Dimitrios Martin (MAR16003880)
    public static int health = 5;
    public Text healthText;


    //sets the health amount value to 5 when the game starts

    private void Start()
    {
        health = 5;

    }

    //views the current score of the coins that have been collected
    void Update()
    {
        healthText.text = "Health : " + health;

    }
}
    
