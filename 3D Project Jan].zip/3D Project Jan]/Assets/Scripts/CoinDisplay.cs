﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CoinDisplay : MonoBehaviour
{
    //Dimitrios Martin (MAR16003880)

    public static int coin = 0;
    public Text coinText;

    //sets the coins amount value to 0 when the game starts
    void Start()
    {
        coin = 0;
    }

    //views the current score of the coins that have been collected
    void Update()
    {
        coinText.text = "Coins : " + coin;
    }
}
