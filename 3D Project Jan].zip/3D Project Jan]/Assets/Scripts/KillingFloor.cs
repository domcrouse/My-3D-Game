﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class KillingFloor : MonoBehaviour
{
    //Dimitrios Martin (MAR16003880)

    [SerializeField]
    GameObject player;
    [SerializeField]
    UnityEvent onDeath;
    

    private void OnTriggerEnter(Collider other)
    {
        if(other.tag == "Player")
        {
            //invokes the method from the screen trasioner to show the game over screen
            onDeath.Invoke();
        }
    }
}
