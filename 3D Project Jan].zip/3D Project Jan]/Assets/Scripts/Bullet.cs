﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    //Dimitrios Martin (MAR16003880)

    //when the bullet hits the player it will deal 1 point of damage
    private void OnTriggerEnter(Collider other)
    {
        if(other.tag == "Player")
        {
            HealthDisplay.health--;
            Destroy(gameObject);
        }
    }
}
