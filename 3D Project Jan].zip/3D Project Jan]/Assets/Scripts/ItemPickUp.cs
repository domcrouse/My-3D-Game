﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class ItemPickUp : MonoBehaviour
{
    //Dimitrios Martin (MAR16003880)

    [SerializeField]
    Item.ItemType typeOfItem;
    [SerializeField]
    GameObject inventoryOrb;
    [SerializeField]
    UnityEvent onCollect;


    //when the player object tagged as player enters the collider the assigned object destroys itself and enables a preset orb in the inventory
    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "Player")
        {
            if (!inventoryOrb.activeSelf)
            {
                inventoryOrb.SetActive(true);
                onCollect.Invoke();
                Destroy(gameObject);
            }
        }
    }
}
