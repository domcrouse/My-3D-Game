﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Coin : MonoBehaviour
{
    //Dimitrios Martin (MAR16003880)

    private void OnTriggerEnter(Collider other)
    {
       if(other.tag == "Player")
        {
            CoinDisplay.coin++;
            //destroys the coin upon contact
            Destroy(gameObject);
        }
    }
}
