﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GrapplingHook : MonoBehaviour
{
    //Dimitrios Martin (MAR16003880)

    public Rigidbody hookRB;
    public Transform hookTrans;
    public Transform hookHolder;
    public float hookSpeed;
    public LineRenderer lr;
    

    void Update()
    {
        //firing hook
        if (Input.GetMouseButtonDown(0))
        {
            if(hookTrans.parent == transform)
            {
                //enable the line renderer
                lr.enabled = true;
                hookTrans.SetParent(null);
                hookRB.constraints = RigidbodyConstraints.None;
                hookRB.AddForce(Camera.main.transform.forward * hookSpeed);
            }
            else
            {
                //returns the hook to the original position
                ReturnHook();
            }
        }
        
    }

    public void ReturnHook()
    {
        lr.enabled = false;
        hookTrans.position = hookHolder.position;
        hookRB.constraints = RigidbodyConstraints.FreezeAll;
        hookTrans.SetParent(hookHolder);
    }

}
