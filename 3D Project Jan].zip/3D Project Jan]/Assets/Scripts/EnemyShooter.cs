﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyShooter : MonoBehaviour
{
    //Dimitrios Martin (MAR16003880)

    [SerializeField]
    Transform player;
    [SerializeField]
    float shootDelay = 2.0f;
    [SerializeField]
    GameObject bulletPrefab;
    [SerializeField]
    float bulletForce = 5.0f;
    [SerializeField]
    float maxDistance = 10f;


    IEnumerator Start()
    {
        //checks to see if the player is within range and fires a bullet prefab clone at the player to damage them
        //shoots again with 3 second intervals and destroys the bullet after 3 seconds if the player has not been hit
        while (true)
        {
            yield return new WaitForSeconds(shootDelay);
            if(Vector3.Distance(player.position, transform.position) < maxDistance)
            {
                GameObject bullet = Instantiate(bulletPrefab, transform.position, Quaternion.identity);
                Vector3 dir = (player.position - transform.position).normalized;
                bullet.GetComponent<Rigidbody>().AddForce(dir * bulletForce);
                Destroy(bullet, 3);
            }
            
        }
    }
    
}
