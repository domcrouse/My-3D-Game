﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MelleEnemy : MonoBehaviour
{
    //Dimitrios Martin (MAR16003880)

    [SerializeField]
    Rigidbody rb;
    [SerializeField]
    Transform player;
    [SerializeField]
    float movementSpeed = 7f;
    [SerializeField]
    float distanceDetect = 10;
    [SerializeField]
    int damage = 1;
    float nextDamage;

    private void OnCollisionEnter(Collision collision)
    {
        //damages the player every 3 seconds
        if(collision.gameObject.tag == "Player")
        {
            if(Time.time > nextDamage)
            {
                nextDamage = Time.time + 2;
                HealthDisplay.health -= damage;
            }
        }
    }

    //updates the enemy movement based on the players position
    void Update()
    {
        if(Vector3.Distance(player.position, transform.position) < distanceDetect)
        {
        Vector3 dir = (player.position - transform.position).normalized;
        rb.velocity = dir * movementSpeed;
        }
    }
}
