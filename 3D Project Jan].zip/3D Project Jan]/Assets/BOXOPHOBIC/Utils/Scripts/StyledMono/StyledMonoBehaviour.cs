﻿using UnityEngine;
using Boxophobic.StyledGUI;

[StyledMonoHideScriptField]
public class StyledMonoBehaviour : MonoBehaviour
{

}
